<?php
require("../config.php");

if (isset($_POST['provider'])) {
    if($_POST['provider'] == 'Payment Gateway'){
        $apiKey = 'XKH1Tecemeqm4sRg90u4GRrh9FXuubZ05ZN6V4sb';

        $curl = curl_init();

        curl_setopt_array($curl, array(
        CURLOPT_FRESH_CONNECT     => true,
        CURLOPT_URL               => "https://payment.tripay.co.id/api/payment/channel",
        CURLOPT_RETURNTRANSFER    => true,
        CURLOPT_HEADER            => false,
        CURLOPT_HTTPHEADER        => array(
            "Authorization: Bearer ".$apiKey
        ),
        CURLOPT_FAILONERROR       => false
        ));

        $response = curl_exec($curl);
        $err = curl_error($curl);

        curl_close($curl);
        if(!empty($err)){
            return "Data Tidak Tersedia";
        }else{
            $data_return = [];
            $return = json_decode($response,true);
            $data_payment = $return['data'];
            foreach ($data_payment as $list) {
               foreach ($list['payment'] as $payment) {
                   array_push($data_return,$payment);
               }
            }
            ?>
        	<option value="0">Pilih...</option>
        	<?php
            foreach($data_return as $v){
        	?>
                <option value="<?=$v['code']?>"><?=$v['name']?></option>
        	<?php
        	}
        }
    }else{
        $post_provider = $conn->real_escape_string($_POST['provider']);
    	$cek_metode = $conn->query("SELECT * FROM metode_depo WHERE id = '$post_provider' ORDER BY id ASC");
    	?>
    	<option value="0">Pilih...</option>
    	<?php
    	while ($data_metode = $cek_metode->fetch_assoc()) {
    	?>
    	<option value="<?php echo $data_metode['id'];?>"><?php echo $data_metode['provider'];?> (<?php echo $data_metode['jenis'];?>)</option>
    	<?php
    	}
    }

} else {
?>
<option value="0">Error.</option>
<?php
}